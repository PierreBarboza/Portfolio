package Case1;

public interface Bonificavel {

    public double getValorBonus();
}